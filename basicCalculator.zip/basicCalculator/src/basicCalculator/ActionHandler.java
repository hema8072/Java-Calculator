package basicCalculator;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class ActionHandler implements ActionListener{
	JTextField display;
	double num1,num2,result;
	char operator;
	boolean operatorpressed;

	public ActionHandler(JTextField display) {
		this.display=display;
		this.operatorpressed=false;
		
	}
    public void actionPerformed(ActionEvent e)
    {
    	String command=e.getActionCommand();
    	if(command.charAt(0)>='0'&& command.charAt(0)<='9') {
    		if(operatorpressed)
    		{
    			display.setText(command);
    			operatorpressed=false;
    		}else {
    			display.setText(display.getText()+command);
    		}
    	}else if(command.charAt(0)=='C')
    		{
    			display.setText("");
    			num1=num2=result=0;
    			operatorpressed=false;
    		}
    		else if(command.charAt(0)=='=') {
    			num2=Double.parseDouble(display.getText());
    			switch(operator) {
    			case '+' :
    				result=num1+num2;
    					break;
    			case '-' :
    				result=num1-num2;
    				break;
    			case '*' :
    				result=num1*num2;
    				break;
    			case'/' :
    				if(num2!=0)
    				{
    					result=num1/num2;
    				}
    				else {
    					display.setText("error");
    					return;
    				}
    				break;
    				
    			}
    		
    		display.setText(String.valueOf(result));
    		operatorpressed=false;
    	}
    	else {
    		if(!display.getText().isEmpty()) {
    			num1=Double.parseDouble(display.getText());
    			operator=command.charAt(0);
    			operatorpressed=true;
    		}
    	}
    	
    }


}
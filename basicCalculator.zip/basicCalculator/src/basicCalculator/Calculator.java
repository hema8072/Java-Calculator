package basicCalculator;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JTextField;

public class Calculator extends JFrame{
	JTextField display;
	ButtonPanel buttonpanel;
	ActionHandler actionhandler;
	
	public Calculator() {
		setLayout(new BorderLayout());
		display=new JTextField();
		display.setEditable(false);
		display.setFont(new Font("Arial",Font.BOLD,30));
		add(display,BorderLayout.NORTH);
		actionhandler=new ActionHandler(display);
		buttonpanel=new ButtonPanel(actionhandler);
		add(buttonpanel,BorderLayout.CENTER);
		
		setTitle("Calculater");
		setSize(300,400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}
	
	
	

	public static void main(String[] args) {
		new Calculator();

	}

}

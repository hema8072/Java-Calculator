/**
 * 
 */
/**
 * 
 */
module basicCalculator {
	requires java.desktop;
}